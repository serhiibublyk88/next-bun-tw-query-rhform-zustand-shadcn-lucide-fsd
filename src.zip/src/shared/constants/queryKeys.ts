// src/shared/constants/queryKeys.ts

export const QUERY_KEYS = {
  cars: ['cars'] as const,
  // если будут ещё ключи, добавляем сюда:
  // user: ['user'] as const,
  // orders: ['orders'] as const,
};
